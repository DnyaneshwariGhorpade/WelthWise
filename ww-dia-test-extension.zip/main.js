/*
 * WealthWise diagnostic extension.
 * Drop this folder into:  C:\Users\<you>\AppData\Roaming\StarUML\extensions\user\
 * Edit files.txt (one absolute .mdj path per line), then start StarUML.
 * Results are written to wwtest_results.log next to this file and shown in a dialog.
 */
var fs = require('fs');
var path = require('path');
var DIR = __dirname;
var RESULT = path.join(DIR, 'wwtest_results.log');
var FILES_TXT = path.join(DIR, 'files.txt');

var lines = [];
function log(msg) {
  lines.push(new Date().toISOString() + ' ' + msg);
  try { fs.writeFileSync(RESULT, lines.join('\n'), 'utf8'); } catch (e) {}
}

var origConsoleError = console.error;
console.error = function () {
  try {
    var t = Array.prototype.slice.call(arguments).map(function (a) {
      if (typeof a === 'string') return a;
      if (a && a.stack) return a.stack;
      try { return JSON.stringify(a); } catch (e) { return String(a); }
    }).join(' ');
    log('[console.error] ' + t);
  } catch (e) {}
  origConsoleError.apply(console, arguments);
};

function describe(elem) {
  if (!elem) return 'null';
  return elem._type + ':"' + elem.name + '" id=' + elem._id;
}

function testFile(filePath) {
  log('======================================================');
  log('FILE: ' + filePath);
  if (!fs.existsSync(filePath)) { log('MISSING FILE (path does not exist)'); return 'MISSING'; }
  try {
    var p = app.project.load(filePath);
    log('project.load returned: ' + describe(p));
  } catch (err) {
    log('!!! project.load THREW: ' + (err && err.stack ? err.stack : err));
    return 'THROW';
  }

  var summary = [];
  try {
    var cur = app.diagrams.getCurrentDiagram();
    log('current diagram: ' + (cur ? describe(cur) : 'NONE'));
    summary.push('current=' + (cur ? cur.name : 'NONE'));
  } catch (err) {
    log('!!! getCurrentDiagram THREW: ' + (err && err.stack ? err.stack : err));
  }

  try {
    var all = app.repository.findAll(function (e) { return e instanceof global.type.Diagram; });
    log('findAll(Diagram) count = ' + all.length);
    all.forEach(function (d) { log('   diagram: ' + describe(d) + ' default=' + d.defaultDiagram); });
    summary.push('diagrams=' + all.length);
  } catch (err) {
    log('!!! findAll THREW: ' + (err && err.stack ? err.stack : err));
  }

  try {
    var cur2 = app.diagrams.getCurrentDiagram();
    if (cur2) {
      var outName = path.join(DIR, 'export_' + path.basename(filePath).replace(/\.mdj$/, '') + '.png');
      try {
        app.commands.execute('project:export-diagram-to-png', cur2, outName);
        log('export OK -> ' + outName + ' (exists=' + fs.existsSync(outName) + ')');
        summary.push('export=OK');
      } catch (err) {
        log('!!! export threw: ' + (err && err.stack ? err.stack : err));
        summary.push('export=THREW');
      }
    } else {
      log('NO CURRENT DIAGRAM -> would show "No diagram to export."');
      summary.push('export=NO-CURRENT');
    }
  } catch (err) {
    log('!!! export wrapper THREW: ' + (err && err.stack ? err.stack : err));
  }
  return summary.join(' | ');
}

function readFileList() {
  try {
    return fs.readFileSync(FILES_TXT, 'utf8').split(/\r?\n/).map(function (s) { return s.trim(); })
      .filter(function (s) { return s && s.indexOf('#') !== 0; });
  } catch (e) {
    log('could not read files.txt: ' + e);
    return [];
  }
}

exports.init = function () {
  setTimeout(function () {
    try {
      log('StarUML version: ' + (app && app.version ? app.version : 'unknown'));
      log('app available: ' + (typeof app !== 'undefined'));
      log('results dir: ' + DIR);
    } catch (err) {
      log('env intro failure: ' + (err && err.stack ? err.stack : err));
    }

    var files = readFileList();
    if (files.length === 0) {
      log('NO PATHS IN files.txt — nothing to test.');
      return;
    }

    var out = files.map(testFile);
    log('======================================================');
    log('SUMMARY: ' + out.join('  ||  '));
    try {
      if (app.dialogs && app.dialogs.showAlertDialog) {
        app.dialogs.showAlertDialog('WW Test\n' + files.map(function (f, i) { return path.basename(f) + ' -> ' + out[i]; }).join('\n'));
      }
    } catch (e) {}
  }, 8000);
};